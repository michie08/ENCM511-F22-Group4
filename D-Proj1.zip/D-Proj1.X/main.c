/*
 * Driver Project-1
 * File:   main.c
 * Author: Michele Pham, 30117189
 *
 * Created on September 17, 2022, 11:39 AM
 */

#include "xc.h"


int main(void) {
    
    TRISAbits.TRISA0 = 1; // Set RA0 as input (GPIO2)
    TRISAbits.TRISA1 = 1; // Set RA1 as input (GPIO3)
    TRISAbits.TRISA2 = 1; // Set RA2 as input (GPIO4)
    TRISAbits.TRISA4 = 1; // Set R44 as input (GPIO5)
    
    TRISBbits.TRISB0 = 0; // Set RB0 as output (GPIO6)
    TRISBbits.TRISB1 = 0; // Set RB1 as output (GPIO7)
    TRISBbits.TRISB2 = 0; // Set RB2 as output (GPIO8)
    TRISBbits.TRISB4 = 0; // Set RB4 as output (GPIO9)
    TRISBbits.TRISB7 = 0; // Set RB7 as output (GPIO10)
    TRISBbits.TRISB8 = 0; // Set RB8 as output (GPIO11)
    TRISBbits.TRISB9 = 0; // Set RB9 as output (GPIO12)
    TRISBbits.TRISB12 = 0; // Set RB12 as output (GPIO13)
    TRISBbits.TRISB13 = 0; // Set RB12 as output (GPIO14)
    
    while(1)
    {
        
        if ((PORTAbits.RA0 == 0) &&  (PORTAbits.RA1 == 0) && (PORTAbits.RA2 == 0) && (PORTAbits.RA4 == 1))
        {
            // 3 consecutive lights should be on 
            LATBbits.LATB0 = 1; // Set RB0 output to hi
            LATBbits.LATB1 = 1; // Set RB1 output to hi
            LATBbits.LATB2 = 1; // Set RB2 output to hi
            LATBbits.LATB4 = 0; // Set the rest of outputs to lo
            LATBbits.LATB7 = 0;
            LATBbits.LATB8 = 0;
            LATBbits.LATB9 = 0;
            LATBbits.LATB12 = 0;
            LATBbits.LATB13 = 0;
           
        }
        else if ((PORTAbits.RA0 == 0) &&  (PORTAbits.RA1 == 0) && (PORTAbits.RA2 == 1) && (PORTAbits.RA4 == 0))
        {
            // 0 lights should be on
            LATBbits.LATB0 = 0; // Set all outputs lo
            LATBbits.LATB1 = 0;
            LATBbits.LATB2 = 0;
            LATBbits.LATB4 = 0;
            LATBbits.LATB7 = 0;
            LATBbits.LATB8 = 0;
            LATBbits.LATB9 = 0;
            LATBbits.LATB12 = 0;
            LATBbits.LATB13 = 0;
        }
        else if ((PORTAbits.RA0 == 0) &&  (PORTAbits.RA1 == 0) && (PORTAbits.RA2 == 1) && (PORTAbits.RA4 == 1))
        {
            // 1 light should be on
            LATBbits.LATB0 = 1; // Set RB0 to hi
            LATBbits.LATB1 = 0; // Set the rest of outputs lo
            LATBbits.LATB2 = 0;
            LATBbits.LATB4 = 0;
            LATBbits.LATB7 = 0;
            LATBbits.LATB8 = 0;
            LATBbits.LATB9 = 0;
            LATBbits.LATB12 = 0;
            LATBbits.LATB13 = 0;
        }
        else if ((PORTAbits.RA0 == 0) &&  (PORTAbits.RA1 == 1) && (PORTAbits.RA2 == 0) && (PORTAbits.RA4 == 0))
        {
            // 1 light should be on
            LATBbits.LATB0 = 1; // Set RB0 to hi
            LATBbits.LATB1 = 0; // Set the rest of outputs lo
            LATBbits.LATB2 = 0;
            LATBbits.LATB4 = 0;
            LATBbits.LATB7 = 0;
            LATBbits.LATB8 = 0;
            LATBbits.LATB9 = 0;
            LATBbits.LATB12 = 0;
            LATBbits.LATB13 = 0;
        }
        else if ((PORTAbits.RA0 == 0) &&  (PORTAbits.RA1 == 1) && (PORTAbits.RA2 == 0) && (PORTAbits.RA4 == 1))
        {
            // 7 consecutive lights should be on
            LATBbits.LATB0 = 1; // Set RB0 to hi
            LATBbits.LATB1 = 1; // Set RB1 to hi
            LATBbits.LATB2 = 1; // Set RB2 to hi
            LATBbits.LATB4 = 1; // Set RB4 to hi
            LATBbits.LATB7 = 1; // Set RB7 to hi
            LATBbits.LATB8 = 1; // Set RB8 to hi
            LATBbits.LATB9 = 1; // Set RB9 to hi
            LATBbits.LATB12 = 0; // Set the rest of outputs lo
            LATBbits.LATB13 = 0;
        }
        else if ((PORTAbits.RA0 == 0) &&  (PORTAbits.RA1 == 1) && (PORTAbits.RA2 == 1) && (PORTAbits.RA4 == 0))
        {
            // 1 light should be on
            LATBbits.LATB0 = 1; // Set RB0 to hi
            LATBbits.LATB1 = 0; // Set the rest of outputs lo
            LATBbits.LATB2 = 0;
            LATBbits.LATB4 = 0;
            LATBbits.LATB7 = 0;
            LATBbits.LATB8 = 0;
            LATBbits.LATB9 = 0;
            LATBbits.LATB12 = 0;
            LATBbits.LATB13 = 0;
        }
        else if ((PORTAbits.RA0 == 0) &&  (PORTAbits.RA1 == 1) && (PORTAbits.RA2 == 1) && (PORTAbits.RA4 == 1))
        {
            // 8 consecutive lights should be on
            LATBbits.LATB0 = 1; // Set RB0 to hi
            LATBbits.LATB1 = 1; // Set RB1 to hi
            LATBbits.LATB2 = 1; // Set RB2 to hi
            LATBbits.LATB4 = 1; // Set RB4 to hi
            LATBbits.LATB7 = 1; // Set RB7 to hi
            LATBbits.LATB8 = 1; // Set RB8 to hi
            LATBbits.LATB9 = 1; // Set RB9 to hi
            LATBbits.LATB12 = 1; // Set RB12 to hi
            LATBbits.LATB13 = 0; // Set RB13 to lo
        }
        else if ((PORTAbits.RA0 == 1) &&  (PORTAbits.RA1 == 0) && (PORTAbits.RA2 == 0) && (PORTAbits.RA4 == 0))
        {
            // 9 consecutive lights should be on
            LATBbits.LATB0 = 1; // Set all outputs to hi
            LATBbits.LATB1 = 1; 
            LATBbits.LATB2 = 1; 
            LATBbits.LATB4 = 1; 
            LATBbits.LATB7 = 1; 
            LATBbits.LATB8 = 1; 
            LATBbits.LATB9 = 1; 
            LATBbits.LATB12 = 1;
            LATBbits.LATB13 = 1;
        }
        else
        {
            // No lights should be on 
            LATBbits.LATB0 = 0; // Set all  to lo
            LATBbits.LATB1 = 0;
            LATBbits.LATB2 = 0;
            LATBbits.LATB4 = 0;
            LATBbits.LATB7 = 0;
            LATBbits.LATB8 = 0;
            LATBbits.LATB9 = 0;
            LATBbits.LATB12 = 0;
            LATBbits.LATB13 = 0;
            
        }
    }
    return 0;
}
