/* 
 * File:   IOs.h
 * Author: miche
 *
 * Created on October 13, 2022, 6:02 PM
 */

#ifndef IOS_H
#define	IOS_H

#ifdef	__cplusplus
extern "C" {
#endif

void IOinit();
void IOCheck();


#ifdef	__cplusplus
}
#endif

#endif	/* IOS_H */