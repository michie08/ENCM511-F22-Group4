#include "xc.h"
#include <p24fxxxx.h>
#include <p24F16KA101.h>
#include "TimeDelay.h"
#include <errno.h>

#define SCALER 15.5
#define OUT LATBbits.LATB8

// Global variables
int flag = 0;
int none = 0;

void IOinit(){
    CLKDIVbits.RCDIV0=0;
    CLKDIVbits.RCDIV1=0;
    CLKDIVbits.RCDIV2=0;
   
    REFOCONbits.ROEN = 0; 
    REFOCONbits.ROSSLP = 0; 
    REFOCONbits.ROSEL = 1; 
    REFOCONbits.RODIV = 0b0000;
    INTCON1bits.NSTDIS=1;
    
    IPC1bits.T2IP = 0b011;
    T2CONbits.TCS=0;
    T2CONbits.T32=0;
    T2CONbits.TCKPS = 0b11;
    T2CONbits.TSIDL = 0;
    
    // inputs
    TRISAbits.TRISA2 = 1;
    TRISAbits.TRISA4 = 1;
    TRISBbits.TRISB4 = 1;
    
    CNPU1bits.CN0PUE = 1;
    CNPU1bits.CN1PUE = 1;
    CNPU2bits.CN30PUE = 1;

    AD1PCFG = 0xFFFF;
    
    // RB8 output
    TRISBbits.TRISB8 = 0;
    OUT = 0;
    
    IEC0bits.T2IE = 1;
}

void IOCheck(){
    // checks if ONLY PB1 is pressed
    while(!PORTAbits.RA2 && PORTAbits.RA4 && PORTBbits.RB4){            
        delay_ms(500);            // delay 0.5 second

        if (flag == 0){
            flag = 1;
            Disp2String("\rPB1 is pressed.");
        }
        none = 0;
    }

    // checks if ONLY PB2 is pressed
    while (!PORTAbits.RA4 && PORTAbits.RA2 && PORTBbits.RB4){     
        delay_ms(2000);            // delay 2 second

        if (flag == 0){
            flag = 1;
            Disp2String("\rPB2 is pressed.");
        }
        none = 0;
    }

    // checks if ONLY PB3 is pressed
    while (!PORTBbits.RB4 && PORTAbits.RA2 && PORTAbits.RA4){        
        delay_ms(3000);            // delay 3 second

        if (flag == 0){
            flag = 1;
            Disp2String("\rPB3 is pressed.");
        }
        none = 0;
    }

    // checks if all 3 pressed
    flag = 0;
    while(!PORTAbits.RA2 && !PORTAbits.RA4 && !PORTBbits.RB4){            
        LATBbits.LATB8 = 1;     // turn on 

        if (flag == 0){
            flag = 1;
            Disp2String("\rAll PBs pressed.");
        }
        none = 0;
    }

    // checks if 2 pbs are pressed
    flag = 0;
    while((!PORTAbits.RA2 && !PORTAbits.RA4) || (!PORTBbits.RB4 && !PORTAbits.RA4) || (!PORTAbits.RA2 && !PORTBbits.RB4)){            
        LATBbits.LATB8 = 1;     // turn on 

        if (flag == 0){
            flag = 1;

            if ((!PORTAbits.RA2 && !PORTAbits.RA4)){
                Disp2String("\rPB1 and PB2 are pressed.");
            }

            else if ((!PORTBbits.RB4 && !PORTAbits.RA4)){
                Disp2String("\rPB2 and PB3 are pressed.");
            }

            else{
                Disp2String("\rPB1 and PB3 are pressed.");
            }
        }
        none = 0;
    }
    
    flag = 0;

    if (none == 0){
        Disp2String("\rNothing pressed.");
        none = 1;
    }
    
    LATBbits.LATB8 = 0;     // turn off   
}