#include "xc.h"
#include <p24fxxxx.h>
#include <p24F16KA101.h>
#include "TimeDelay.h"
#include <errno.h>
#include <stdio.h>
#include "IOs.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define SCALER 15.5
#define OUT LATBbits.LATB8

// Global variables
int CNflag = 0;     // FLAG for CN interupt
char print[100];


int disp1 = 0;
int disp2 = 0;
int intro = 0;
int lev1 = 0;       // no reinit and print number sequence stuff
int lev2 = 0;       // no reinit and print number sequence stuff
int pressed = 0;    //control buttons being pressed in level 1
int gameOver = 0;   //leave level
int end = 0;    // game end and restart option
int stay = 0;   // stay in while loop in math
int block = 0;  // when pressing buttons for math block pressed var changing in interrupt
int try = 0;    // players get 2 tries

int oneSecond = 80;
void IOinit(){
    
    CLKDIVbits.RCDIV0=0;
    CLKDIVbits.RCDIV1=0;
    CLKDIVbits.RCDIV2=0;
   
    REFOCONbits.ROEN = 0; 
    REFOCONbits.ROSSLP = 0; 
    REFOCONbits.ROSEL = 1; 
    REFOCONbits.RODIV = 0b0000;
    INTCON1bits.NSTDIS=1;
    
    IPC1bits.T2IP = 0b011;
    T2CONbits.TCS=0;
    T2CONbits.T32=0;
    T2CONbits.TCKPS = 0b11;
    T2CONbits.TSIDL = 0;
    
    // inputs
    TRISAbits.TRISA2 = 1;
    TRISAbits.TRISA4 = 1;
    TRISBbits.TRISB4 = 1;
    
    // Enable CN on RA2 - CN30, RA4 - CN0 and RB4 - CN1
    CNEN2bits.CN30IE = 1;   // PB1 RA2 CN
    CNEN1bits.CN0IE = 1;    // PB2 RA4 CN
    CNEN1bits.CN1IE = 1;    // PB3 RB4 CN
//    
    // CN Interrupt Settings
    IPC4bits.CNIP = 6;      // Sets interrupt priority to 6 for CN. 7 highest 1 lowest 0 disable
    IFS1bits.CNIF = 0;      // Clear CN interrupt flag
    IEC1bits.CNIE = 1;      // Enable CN interrupt
    
    CNPU1bits.CN0PUE = 1;
    CNPU1bits.CN1PUE = 1;
    CNPU2bits.CN30PUE = 1;
    
    // Config pull up resistors on RA2 - CN30, RA4 - CN0 and RB4 - CN1
    CNPU2bits.CN30PUE = 1;  // PB1 RA2 PU
    CNPU1bits.CN0PUE = 1;   // PB2 RA4 PU
    CNPU1bits.CN1PUE = 1;   // PB3 RB4 PU
    
    AD1PCFG = 0xFFFF;
    
    // RB8 output
    TRISBbits.TRISB8 = 0;
    OUT = 0;
    
    IEC0bits.T2IE = 1;
}

void IOCheck(){
    
    while(intro == 0){
        if(disp1 == 0){
            Disp2String("Hi I'm Simon.\n\r");
            delay_ms(1000);
            Disp2String("Welcome to my game: Simon Says.\n\r");
            delay_ms(2000);
            Disp2String("Press the buttons in the correct order.\n\r");
            delay_ms(2000);
            Disp2String("Or get blown up :)\n\r");
            delay_ms(3000);
            Disp2String("Simon Says press a button to continue.\n\r");
            disp1 = 1;
        }
        if(disp1 == 1){
            if(!PORTAbits.RA2 || !PORTAbits.RA4 || !PORTBbits.RB4){
               Disp2String("\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
               Disp2String("Instructions:\n\r");
               delay_ms(2000);
               Disp2String("A sequence of numbers (ranging from 1-3) will appear on the screen\n\r");
               delay_ms(2000);
               Disp2String("Press the corresponding PB to the number shown on the screen\n\r");
               delay_ms(2500);
               Disp2String("If you press the wrong button, 2 of the PBs will turn into bombs :) \n\r");
               delay_ms(2000);
               Disp2String("Press a bomb and you will be blown up :D and the game will be over :( \n\n\r");
               delay_ms(3500);
               Disp2String("To determine which PB is not a bomb, a number will appear on the screen \n\r");
               delay_ms(2000);
               Disp2String("If the number is divisible by 3 (yes you will have to do math),\n\rPB1 is the correct button \n\r");
               delay_ms(2500);
               Disp2String("If the number is not divisible by 3 and has a remainder of 1,\n\rPB2 is the correct button \n\r");
               delay_ms(2500);
               Disp2String("If the number is not divisible by 3 and has a remainder of 2,\n\rPB3 is the correct button \n\r");
               delay_ms(2500);
               Disp2String("Pretty simple \n\r");
               delay_ms(2500);
               Disp2String("\nPress the right button and you will return to the level. \n\r");
               delay_ms(2500);
               Disp2String("The time for each level is random. \n\r");
               delay_ms(2500);
               Disp2String("Good Luck ;) \n\n\r");
               delay_ms(1500);
               Disp2String("Simon Says press any button to begin the game\n\r");
               intro = 1; 
            }
        }
    }
    
    while(intro == 2){
        if(disp1 == 0){
            Disp2String("Hi I'm Simon.\n\r");
            delay_ms(1000);
            Disp2String("Ready to play again ;).\n\r");
            Disp2String("Simon Says press any button to begin the game.\n\r");
            Disp2String("\n\n\n\n\n\n\n\n\n\n\n");
            disp1 = 1;
            intro = 1;
        }
    }
    
    // any button press start game
    if (!PORTAbits.RA2 || !PORTAbits.RA4 || !PORTBbits.RB4){
        levelOne();
    }
    
    if(gameOver == 1){
        //reint all the variables here;
        if (disp2 == 0){
            disp2 = 1;
            Disp2String("\nSimon Says you're a loser :) \n\r");
            Disp2String("Simon Says press any button to redeem yourself.\n\r");
            Disp2String("\n\n\n\n\n\n\n\n\n");
        }
        
        int wait = 0; 
        while (wait == 0){
            if (!PORTAbits.RA2 || !PORTAbits.RA4 || !PORTBbits.RB4){
            CNflag = 0;     // FLAG for CN interupt
            disp1 = 0;
            disp2 = 0;
            intro = 2;  
            lev1 = 0;       // no reinit and print number sequence stuff
            lev2 = 0;       // no reinit and print number sequence stuff
            pressed = 0;    //control buttons being pressed in level 1
            gameOver = 0;   //leave level
            end = 0;    // game end and restart option
            stay = 0;   // stay in while loop in math
            block = 0;  // when pressing buttons for math block pressed var changing in interrupt
            try = 0;    // players get 2 tries

            wait = 1;
            }
        }       
    }
    
    else if (end == 1){
        //reint all the variables here;
        if (disp2 == 0){
            disp2 = 1;
            Disp2String("Simon Says if you have nothing better to do..\n\rPress a button to play again :D.\n\r");
            Disp2String("\n\n\n\n\n\n\n\n\n\n\n\n");
        }
        
        int wait = 0; 
        while (wait == 0){
            if (!PORTAbits.RA2 || !PORTAbits.RA4 || !PORTBbits.RB4){
            CNflag = 0;     // FLAG for CN interupt
            disp1 = 0;
            disp2 = 0;
            intro = 2;  
            lev1 = 0;       // no reinit and print number sequence stuff
            lev2 = 0;       // no reinit and print number sequence stuff
            pressed = 0;    //control buttons being pressed in level 1
            gameOver = 0;   //leave level
            end = 0;        // game end and restart option
            stay = 0;       // stay in while loop in math
            block = 0;      // when pressing buttons for math block pressed var changing in interrupt
            try = 0;        // players get 2 tries

            wait = 1;           
            }
        }       
    }
            
}

void levelOne(){
    int count = 0;          // which sequence

    int number[6];
    uint64_t timer = (rand() % (12 - 8 + 1)) + 8;
    uint64_t tracker = 0;
    
    if(lev1 == 0){
        delay_ms(2000);
        Disp2String("\n\n\n\n\n\n\n\n\n\n\n\n\n");
        Disp2String("Simon Says press these buttons:\n\r");
        number[0] = (rand() % (3 - 1 + 1)) + 1;
        number[1] = (rand() % (3 - 1 + 1)) + 1;
        number[2] = (rand() % (3 - 1 + 1)) + 1;
        number[3] = (rand() % (3 - 1 + 1)) + 1;
        number[4] = (rand() % (3 - 1 + 1)) + 1;
        number[5] = (rand() % (3 - 1 + 1)) + 1; 
            
        sprintf(print, "%01d, %01d, %01d, %01d, %01d, %01d\n\r", number[0], number[1], number[2], number[3], number[4], number[5]);
        Disp2String(print);
        Disp2String("\n\n\n\n\n\n\n\n\n\n\n");
        lev1 = 1;
    }
    
    // users pressing buttons
    int i = 0;
    int delay = 0;
    while(count < 6 && end == 0 && try < 2){
        while(delay == 0){
            delay_ms(750);
            delay = 1;
        }
        delay_ms(500);
        
        int remaining = timer - (tracker/2);   
        if(tracker % 2 == 0){        

            sprintf(print, "Time Remaining: %01d seconds\r", remaining);
            
            Disp2String(print);
        }
        
        if(remaining == 0){
            gameOver = 1;
            end = 1;
            Disp2String("\nTimes Up!\n\r");
            return;
        }
        tracker ++;

        if (pressed == 0){

            while((!PORTAbits.RA2 || !PORTAbits.RA4 || !PORTBbits.RB4) && pressed == 0 && gameOver == 0){            //pb pressed
                pressed = 1;
                
                int check = checkPB(number[i]);
                if(check == 0){                  
                    try ++;
                    
                    if(try >= 2){
                        delay_ms(1500);
                        Disp2String("\nWrong again!\n\r");
                        delay_ms(1500);
                        Disp2String("Simon Says...\n\r");
                        delay_ms(1500);
                        Disp2String("He's disappointed :( \n\r");
                        delay_ms(2000);
                        gameOver = 1;
                        end = 1;
                        return;
                    }
                    
                    if(gameOver == 1){
                        end = 1;
                        break;
                    }
                    
                    int level = 1;
                    
                    mathTime(level);                  
                    
                    if(gameOver == 1){
                        delay_ms(1500);
                        Disp2String("\nTik\n\r");
                        delay_ms(1500);
                        Disp2String("Tik\n\r");
                        delay_ms(1500);
                        Disp2String("BOOM\n\r");
                        delay_ms(2000);
                        end = 1;
                        return;
                    }
                    
                    Disp2String("\n\n\n\n\n\n\n\n\n\n\n");
                    Disp2String("Correct!. Simon Says start Level One again!\n\r");
                    Disp2String("Last Try ;)\n\n\r");
                    i = -1;
                    count = -1;
                    tracker = 0;
                    Disp2String("Simon Says press these buttons:\n\r");
                    number[0] = (rand() % (3 - 1 + 1)) + 1;
                    number[1] = (rand() % (3 - 1 + 1)) + 1;
                    number[2] = (rand() % (3 - 1 + 1)) + 1;
                    number[3] = (rand() % (3 - 1 + 1)) + 1;
                    number[4] = (rand() % (3 - 1 + 1)) + 1;
                    number[5] = (rand() % (3 - 1 + 1)) + 1; 
                    sprintf(print, "%01d, %01d, %01d, %01d, %01d, %01d\n\r", number[0], number[1], number[2], number[3], number[4], number[5]);
                    Disp2String(print);
                    Disp2String("\n\n\n\n\n\n\n\n\n\n");
                                       
                }
                
                count ++;
                i++;              
            } 
        }
    }
    
    if(gameOver == 1){
        end = 1;
        return;
    }
    Disp2String("\nSimon Says Hooray\n\r");
    Disp2String("Starting Level Two\n\r");
    try = 0;
    levelTwo();
    return;
}

void levelTwo(){
    int count = 0;          // which sequence

    int number[15];
    uint64_t timer = (rand() % (17 - 12 + 1)) + 8;
    uint64_t tracker = 0;
    
    // generate 6 random numbers between 1 - 3
    if(lev2 == 0){

        Disp2String("Simon Says press these buttons:\n\r");
        number[0] = (rand() % (3 - 1 + 1)) + 1;
        number[1] = (rand() % (3 - 1 + 1)) + 1;
        number[2] = (rand() % (3 - 1 + 1)) + 1;
        number[3] = (rand() % (3 - 1 + 1)) + 1;
        number[4] = (rand() % (3 - 1 + 1)) + 1;
        number[5] = (rand() % (3 - 1 + 1)) + 1; 
        number[6] = (rand() % (3 - 1 + 1)) + 1;
        number[7] = (rand() % (3 - 1 + 1)) + 1;
        number[8] = (rand() % (3 - 1 + 1)) + 1;
        number[9] = (rand() % (3 - 1 + 1)) + 1;
        number[10] = (rand() % (3 - 1 + 1)) + 1;
        number[11] = (rand() % (3 - 1 + 1)) + 1; 
        number[12] = (rand() % (3 - 1 + 1)) + 1;
        number[13] = (rand() % (3 - 1 + 1)) + 1;
        number[14] = (rand() % (3 - 1 + 1)) + 1;
        sprintf(print, "%01d, %01d, %01d, %01d, %01d, %01d, %01d, %01d, %01d, %01d, %01d, %01d, %01d, %01d, %01d\n\r", number[0], number[1], number[2], number[3], 
                number[4], number[5], number[6], number[7], number[8], number[9], number[10], number[11],
                number[12], number[13], number[14]);
        Disp2String(print);
        Disp2String("\n\n\n\n\n\n\n\n\n\n\n");
        lev2 = 1;
    }
    
    // users pressing buttons
    int i = 0;
    while(count < 15 && end == 0 && try < 2){
        
        delay_ms(500);
        
        int remaining = timer - (tracker/2);   
        if(tracker % 2 == 0){        

            sprintf(print, "Time Remaining: %01d seconds\r", remaining);
            
            Disp2String(print);
        }
        
        if(remaining == 0){
            gameOver = 1;
            end = 1;
            Disp2String("\nTimes Up!\n\r");
            return;
        }
        tracker ++;
        
        if (pressed == 0){

            while((!PORTAbits.RA2 || !PORTAbits.RA4 || !PORTBbits.RB4) && pressed == 0 && gameOver == 0){            //pb pressed           
                pressed = 1;
                int check = checkPB(number[i]);
                if(check == 0){
                    
                    try ++;
                    if(try >= 2){
                        delay_ms(1500);
                        Disp2String("\nWrong again!\n\r");
                        delay_ms(1500);
                        Disp2String("Simon Says...\n\r");
                        delay_ms(1500);
                        Disp2String("He's disappointed :( \n\r");
                        delay_ms(2000);
                        end = 1;
                        gameOver = 1;
                        return;
                    }
                    if(gameOver == 1){
                        end = 1;
                        break;
                    }
                    int level = 2;

                    mathTime(level);                
                    
                    if(gameOver == 1){
                        end = 1;
                        delay_ms(1500);
                        Disp2String("\nTik\n\r");
                        delay_ms(1500);
                        Disp2String("Tik\n\r");
                        delay_ms(1500);
                        Disp2String("BOOM\n\r");
                        delay_ms(2000);
                        return;
                    }
                    
                    Disp2String("\n\n\n\n\n\n\n\n\n\n\n");
                    Disp2String("Correct!. Simon Says start Level Two again!\n\r");
                    Disp2String("Last Try ;)\n\n\r");
                    i = -1;
                    count = -1;
                    Disp2String("Simon Says press these buttons:\n\r");
                    number[0] = (rand() % (3 - 1 + 1)) + 1;
                    number[1] = (rand() % (3 - 1 + 1)) + 1;
                    number[2] = (rand() % (3 - 1 + 1)) + 1;
                    number[3] = (rand() % (3 - 1 + 1)) + 1;
                    number[4] = (rand() % (3 - 1 + 1)) + 1;
                    number[5] = (rand() % (3 - 1 + 1)) + 1; 
                    number[6] = (rand() % (3 - 1 + 1)) + 1;
                    number[7] = (rand() % (3 - 1 + 1)) + 1;
                    number[8] = (rand() % (3 - 1 + 1)) + 1;
                    number[9] = (rand() % (3 - 1 + 1)) + 1;
                    number[10] = (rand() % (3 - 1 + 1)) + 1;
                    number[11] = (rand() % (3 - 1 + 1)) + 1; 
                    number[12] = (rand() % (3 - 1 + 1)) + 1;
                    number[13] = (rand() % (3 - 1 + 1)) + 1;
                    number[14] = (rand() % (3 - 1 + 1)) + 1;
                    sprintf(print, "%01d, %01d, %01d, %01d, %01d, %01d, %01d, %01d, %01d, %01d, %01d, %01d, %01d, %01d, %01d\n\r", number[0], number[1], number[2], number[3], 
                            number[4], number[5], number[6], number[7], number[8], number[9], number[10], number[11],
                            number[12], number[13], number[14]);
                    Disp2String(print);
                    Disp2String("\n\n\n\n\n\n\n\n\n");
                                       
                }
                tracker = 0;
                count ++;
                i++; 
            } 
        }
    }
    Disp2String("\nSimon Says SLAYY\n\r");
    end = 1;
    return;
}

int checkPB(int num){
    if(num == 1){
        if(!PORTAbits.RA2 && PORTAbits.RA4 && PORTBbits.RB4){
            return 1;
        }               
    }
    
    else if(num == 2){
        if(PORTAbits.RA2 && !PORTAbits.RA4 && PORTBbits.RB4){
            return 1;
        } 
    }
    
    else{
        if(PORTAbits.RA2 && PORTAbits.RA4 && !PORTBbits.RB4){
            return 1;
        } 
    }
    return 0;
}

void mathTime(int level){
    delay_ms(500);
    Disp2String("\n\n\n\n\n\n\n\n\n\n\n\n");
    Disp2String("\n\nWRONG BUTTON");
    Disp2String("\n\rSimon Says it's time to do math my lovelies ;) \n\r");
    int value;
    uint64_t timer;
    uint64_t tracker = 0;
    if (level == 1){
        timer = (rand() % (12 - 10 + 1)) + 8;
        value = (rand() % (999 - 5 + 1)) + 1;
    }
    
    else if (level == 2){
        timer = (rand() % (10 - 8 + 1)) + 8;
        value = (rand() % (9999 - 1200 + 1)) + 1;
    }
    sprintf(print, "Divide %01d by 3\n\n\r", value);
    Disp2String(print);
    
    Disp2String("\n\n\n\n\n\n\n\n\n");
    block = 1;
    while (stay == 0){
 
        delay_ms(750);
        
        int remaining = timer - (tracker/2);   
        if(tracker % 2 == 0){        
            sprintf(print, "Time Remaining: %01d seconds\r", remaining);
            Disp2String(print);
        }
        
        if(remaining == 0){
            gameOver = 1;
            end = 1;
            return;
        }
        tracker ++;
        if ((value % 3) == 0){
            if(!PORTAbits.RA2 && PORTAbits.RA4 && PORTBbits.RB4){
                stay = 1;
                block = 0;
                gameOver = 0;
                delay_ms(500);
                return;
            }
            
            else if(PORTAbits.RA2 && !PORTAbits.RA4 && PORTBbits.RB4){
                stay = 1;
                block = 0;
                gameOver = 1;
                delay_ms(500);
                return;
            }
            
            else if(PORTAbits.RA2 && PORTAbits.RA4 && !PORTBbits.RB4){
                stay = 1;
                block = 0;
                gameOver = 1;
                delay_ms(500);
                return;
            }

            else{
                gameOver = 1;
            }
        }
    
        else if ((value % 3) == 1){
            if(PORTAbits.RA2 && !PORTAbits.RA4 && PORTBbits.RB4){
                stay = 1;
                block = 0;
                gameOver = 0;
                delay_ms(500);
                return;
            }
            
            else if(!PORTAbits.RA2 && PORTAbits.RA4 && PORTBbits.RB4){
                stay = 1;
                block = 0;
                gameOver = 1;
                delay_ms(500);
                return;
            }
            
            else if(PORTAbits.RA2 && PORTAbits.RA4 && !PORTBbits.RB4){
                stay = 1;
                block = 0;
                gameOver = 1;
                delay_ms(500);
                return;
            }

            else{
                gameOver = 1;
            }
        }

        else{
            if(PORTAbits.RA2 && PORTAbits.RA4 && !PORTBbits.RB4){
                stay = 1;
                block = 0;
                gameOver = 0;
                delay_ms(500);
                return;
            }
            
            else if(PORTAbits.RA2 && !PORTAbits.RA4 && PORTBbits.RB4){
                stay = 1;
                block = 0;
                gameOver = 1;
                delay_ms(500);
                return;
            }
            
            else if(!PORTAbits.RA2 && PORTAbits.RA4 && PORTBbits.RB4){
                stay = 1;
                block = 0;
                gameOver = 1;
                delay_ms(500);
                return;
            }

            else{
                gameOver = 1;
            }
        }
    }
}
void __attribute__ ((interrupt, no_auto_psv)) _CNInterrupt(void){
    CNflag = 1;
    IFS1bits.CNIF = 0;      // Clear interrupt flag   
    
    if (block == 0){
       pressed = 0; 
    }

    Nop();
    return;
}
