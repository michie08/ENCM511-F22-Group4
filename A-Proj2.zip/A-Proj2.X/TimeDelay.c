#include <stdio.h>
#include "xc.h"

#define SCALER 15.5
#define OUT LATBbits.LATB8
void __attribute__((interrupt, no_auto_psv)) _T2Interrupt(void)
{
    IFS0bits.T2IF=0; //Clear timer 2 interrupt flag
    T2CONbits.TON=0; //stop timer
    // TMR2flag = 1; // global variable created by user
    OUT = ~OUT; // is this needed
    TMR2 = 0;
    
    return;
}

void delay_ms(uint16_t time_ms){
    PR2 = SCALER* time_ms;
    T2CONbits.TON = 1;
    Idle();
    T2CONbits.TON = 0;
    return;
}