/* 
 * File:   TimeDelay.h
 * Author: miche
 *
 * Created on October 13, 2022, 6:02 PM
 */

#ifndef TIMEDELAY_H
#define	TIMEDELAY_H

#ifdef	__cplusplus
extern "C" {
#endif


void __attribute__((interrupt, no_auto_psv)) _T2Interrupt(void);
void clk();
void delay_ms(uint16_t time_ms);
    
    

#ifdef	__cplusplus
}
#endif

#endif	/* TIMEDELAY_H */