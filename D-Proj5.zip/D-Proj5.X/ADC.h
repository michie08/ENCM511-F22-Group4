/* 
 * File:   ADC.h
 * Author: miche
 *
 * Created on November 18, 2022, 10:31 AM
 */

 
#ifndef ADC_H
#define	ADC_H

#include <xc.h> 

#ifdef	c
extern "C" {
#endif

#ifdef	c
}
#endif

uint16_t do_ADC(void);
//void PrintADC(uint16_t ADCValue);

#endif

