#ifndef TIMEDELAY_H
#define	TIMEDELAY_H

#include <xc.h> 

#ifdef	c
extern "C" {
#endif

#ifdef	c
}
#endif

void Delay_ms(uint16_t time_ms);
void __attribute__((interrupt, no_auto_psv))_T2Interrupt(void);
void TMR2config(void);

#endif

