#include "ADC.h"
#include "xc.h"
#include "IOs.h"
#include "UART2.h"
#include "ChangeClk.h"
uint16_t do_ADC(void)
{
    uint16_t ADCValue;
    
    /* Initializing ADC */
    AD1CON1bits.ADON = 1;       //turn on ADC
    AD1CON1bits.FORM = 0b00;    //output unsigned integer
    AD1CON1bits.SSRC = 0b111;   //auto-convert after sampling
    AD1CON1bits.ASAM = 0;       //start sampling when the SAMP bit is set
    
    AD1CON2bits.VCFG = 0b000;   //use reference voltage
    AD1CON2bits.CSCNA = 0;      //Don't scan inputs
    AD1CON2bits.BUFM = 0;       //output 16 bit word
    AD1CON2bits.ALTS = 0;       //use MUXA settings
    
    AD1CON3bits.ADRC = 0;       //use system clock
    AD1CON3bits.SAMC = 0b11111; //slow signal so slowest sampling time uses least amount of power
    
    AD1CHSbits.CH0NA = 0;       //use VRef-
    AD1CHSbits.CH0SA = 0b0101;  //use VRef+
    
    AD1CON1bits.SAMP = 1;       //begin sampling
    while(AD1CON1bits.DONE == 0)//wait until sampling and converting is done
    {}
    
    ADCValue = ADC1BUF0;        //get ADC output from buffer
    AD1CON1bits.SAMP = 0;       //stop sampling
    AD1CON1bits.ADON = 0;       //turn off ADC
    
    PrintADC(ADCValue); // print to terminal
    
    return ADCValue;
}

void PrintADC(uint16_t ADCValue)
{    
    
    uint16_t num = ADCValue / 20;  //number of bars to print
    NewClk(8);                     // set clk to 8 MHz for smooth printing
    
    XmitUART2('-', num);         //print bar graph
    XmitUART2(' ', 51 - num);    //clear line
    Disp2Hex(ADCValue);          //Disp hex value at the end of bar
    XmitUART2('\r', 1);          //return
    
    NewClk(32);					// reset clk
    
    return;
    
}