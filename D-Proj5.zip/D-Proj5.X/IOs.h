/* 
 * File:   IOs.h
 * Author: miche
 *
 * Created on November 18, 2022, 10:34 AM
 */

 #ifndef IOs_H
#define	IOs_H

#include <xc.h>

#ifdef	c
extern "C" {
#endif

#ifdef	c
}
#endif

void IOinit(void);
void IOCheck();

#endif

