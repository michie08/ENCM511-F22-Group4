/* 
 * File:   ChangeClk.h
 * Author: miche
 *
 * Created on November 18, 2022, 10:33 AM
 */

#ifndef CHANGECLK_H
#define	CHANGECLK_H

#ifdef	c
extern "C" {
#endif

#ifdef	c
}
#endif

void NewClk(unsigned int);

#endif
