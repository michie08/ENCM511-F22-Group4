#include "xc.h"
#include "ChangeClk.h"

void NewClk(unsigned int clkval)  
{
    char COSCNOSC;
    if (clkval == 8)  //8MHz
    {
        COSCNOSC = 0x00;
    }
    else if (clkval == 500) // 500 kHz
    {
        COSCNOSC = 0x66;
    }
    else if (clkval== 32) //32 kHz
    {
        COSCNOSC = 0x55; 
    }
    else // default
    {
        COSCNOSC = 0x55;
    }

    SRbits.IPL = 7;  // Disable interrupts
    CLKDIVbits.RCDIV = 0;  // CLK div = 0
    __builtin_write_OSCCONH(COSCNOSC);
    __builtin_write_OSCCONL(0x01);
    OSCCONbits.OSWEN=1;
    while(OSCCONbits.OSWEN==1){} 
    SRbits.IPL = 0;  //enable interrupts
}


