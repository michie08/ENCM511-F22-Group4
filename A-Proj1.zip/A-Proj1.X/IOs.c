#include "xc.h"
#include <p24fxxxx.h>
#include <p24F16KA101.h>
#include "TimeDelay.h"
#include <errno.h>
#include <stdio.h>
#include "IOs.h"

#define SCALER 15.5
#define OUT LATBbits.LATB8

// Global variables
int CNflag = 0;     // FLAG for CN interupt
int min = 0;        
int sec = 0;
int dispflag = 0;
int count = 0;      // for determining short vs long presses
int pause = 0;  
int s = 0;          // if short pause s = 1
char print[100];

void IOinit(){
    
    CLKDIVbits.RCDIV0=0;
    CLKDIVbits.RCDIV1=0;
    CLKDIVbits.RCDIV2=0;
   
    REFOCONbits.ROEN = 0; 
    REFOCONbits.ROSSLP = 0; 
    REFOCONbits.ROSEL = 1; 
    REFOCONbits.RODIV = 0b0000;
    INTCON1bits.NSTDIS=1;
    
    IPC1bits.T2IP = 0b011;
    T2CONbits.TCS=0;
    T2CONbits.T32=0;
    T2CONbits.TCKPS = 0b11;
    T2CONbits.TSIDL = 0;
    
    // inputs
    TRISAbits.TRISA2 = 1;
    TRISAbits.TRISA4 = 1;
    TRISBbits.TRISB4 = 1;
    
    // Enable CN on RA2 - CN30, RA4 - CN0 and RB4 - CN1
    CNEN2bits.CN30IE = 1;   // PB1 RA2 CN
    CNEN1bits.CN0IE = 1;    // PB2 RA4 CN
    CNEN1bits.CN1IE = 1;    // PB3 RB4 CN
//    
    // CN Interrupt Settings
    IPC4bits.CNIP = 6;      // Sets interrupt priority to 6 for CN. 7 highest 1 lowest 0 disable
    IFS1bits.CNIF = 0;      // Clear CN interrupt flag
    IEC1bits.CNIE = 1;      // Enable CN interrupt
    
    CNPU1bits.CN0PUE = 1;
    CNPU1bits.CN1PUE = 1;
    CNPU2bits.CN30PUE = 1;
    
    // Config pull up resistors on RA2 - CN30, RA4 - CN0 and RB4 - CN1
    CNPU2bits.CN30PUE = 1;  // PB1 RA2 PU
    CNPU1bits.CN0PUE = 1;   // PB2 RA4 PU
    CNPU1bits.CN1PUE = 1;   // PB3 RB4 PU
    
    AD1PCFG = 0xFFFF;
    
    // RB8 output
    TRISBbits.TRISB8 = 0;
    OUT = 0;
    
    IEC0bits.T2IE = 1;
}

void IOCheck(){
    // checks if ONLY PB1 is pressed
    count = 0;
    while(!PORTAbits.RA2 && PORTAbits.RA4 && PORTBbits.RB4){            
        delay_ms(1000);              // delay 1 second
                     
        if (min >= 0 && min < 59){
            min++;
            sprintf(print, "%02d m : %02d s        \r", min, sec);
            Disp2String(print);
        }            
    }
   
    // checks if ONLY PB2 is pressed
    count = 0;
    while (!PORTAbits.RA4 && PORTAbits.RA2 && PORTBbits.RB4){     
        delay_ms(1000);            // delay 1 second
      
        if (sec >= 0 && sec < 59){
            sec++;
            sprintf(print, "%02d m : %02d s        \r", min, sec);
            Disp2String(print);
        }

        else if(sec == 59){           
            if(min >= 0 && min < 59){
                min ++; 
                sec = 0;
            }
        }
    }

    // checks if ONLY PB3 is pressed
    count = 0;
    dispflag = 0;
    while (!PORTBbits.RB4 && PORTAbits.RA2 && PORTAbits.RA4){        
        delay_ms(1500);            // delay 3 second
        
        if (count < 1){          
            count++;  
            pause = 1 - pause; 
            s = 1;
        }
        
        else{
            min = 0;            
            sec = 0;
            
            if(dispflag == 0){
                sprintf(print, "%02d m : %02d s        \r", min, sec);
                Disp2String(print); 
                dispflag = 1;
            }
                  
            
            s = 0;                      // no count down cause 00 
            pause = 0;                  // reset pause
        }
    }
    
    count = 0;
    CNflag = 0;
    OUT = 0;
    if (s == 1 && CNflag == 0){      
        while(pause == 1){
            delay_ms(1100);
            OUT = ~OUT;
            
            
            if (min >= 0 && sec > 0){
                sprintf(print, "%02d m : %02d s        \r", min, sec);
                Disp2String(print);
            }

            if (min == 0 && sec == 0){
                
                pause = 0;
                LATBbits.LATB8 = 1;     // turn on
                sprintf(print, "%02d m : %02d s - ALARM\r", min, sec);
                Disp2String(print);
                
                
                 
            }

            else if (min > 0){
                if (sec == 0){
                    if (min > 0){
                        min--;
                    }                
                    sec = 59;
                }

                else{
                    sec --;
                }
            }

            else{
                sec --;
            }

            

            if (CNflag == 1){
                break;
            }
        }
    }         
}

void __attribute__ ((interrupt, no_auto_psv)) _CNInterrupt(void){
    CNflag = 1;
    IFS1bits.CNIF = 0;      // Clear interrupt flag   

    Nop();
    return;
}
